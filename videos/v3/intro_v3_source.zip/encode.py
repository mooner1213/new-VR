from pathlib import Path
import subprocess
p=Path('/workspace/intro-video-v3');font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
f="vignette=PI/5,fade=t=in:st=0:d=0.3,fade=t=out:st=17.1:d=0.9,tpad=stop_mode=clone:stop_duration=2,drawtext=fontfile="+font+":text='잔해 속의 숨':fontsize=34:fontcolor=0xd8e0e2:x=(w-tw)/2:y=h*.42:alpha='if(lt(t,18),0,min(1,(t-18)/.5))',drawtext=fontfile="+font+":text='BREATH IN THE RUBBLE':fontsize=13:fontcolor=0x8fa4ad:x=(w-tw)/2:y=h*.55:alpha='if(lt(t,18.2),0,min(1,(t-18.2)/.5))',format=yuv420p"
subprocess.run(['ffmpeg','-y','-v','error','-framerate','24','-start_number','1','-i',str(p/'frames/%04d.png'),'-i','/workspace/intro-video-v2/sound.wav','-vf',f,'-t','20','-c:v','libx264','-preset','fast','-crf','18','-c:a','aac','-b:a','192k','-movflags','+faststart',str(p/'breath_in_the_rubble_intro_v3.mp4')],check=True)
