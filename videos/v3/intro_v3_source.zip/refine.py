import bpy,math
from mathutils import Vector
s=bpy.context.scene
led=bpy.data.lights['Smartphone LED only'];led.spot_size=math.radians(108)
d=bpy.data.lights.new('Phone screen and scattered LED spill','POINT');d.energy=1.3;d.color=(.55,.68,.85);d.shadow_soft_size=.08;o=bpy.data.objects.new(d.name,d);bpy.context.collection.objects.link(o);o.parent=bpy.data.objects['LEFT hand smartphone rig'];o.location=(0,-.05,.065)
for fr in range(1,434,2):
 t=(fr-1)/24;d.energy=.025 if t<3.9 else 1.3;d.keyframe_insert(data_path='energy',frame=fr)
# Looking around is a real camera rotation inside a fixed lower-body position.
cam=s.camera
for fr in range(1,434,2):
 t=(fr-1)/24;s.frame_set(fr);target=Vector((.19*math.sin((t-5)*.65),.65,-.19))
 if 6<t<8:target.z-=.16*math.sin((t-6)/2*math.pi)
 if 9<t<12:target.z+=.48*math.sin((t-9)/3*math.pi)
 cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.keyframe_insert(data_path='rotation_euler',frame=fr)
s.render.filepath='/workspace/intro-video-v3/frames/';s.frame_set(169)
bpy.ops.wm.save_as_mainfile(filepath='/workspace/intro-video-v3/intro_v3.blend');s.render.filepath='/workspace/intro-video-v3/test_refined.png';bpy.ops.render.render(write_still=True)
