import bpy
s=bpy.context.scene;p=bpy.data.objects['LEFT hand smartphone rig'];d=bpy.data.lights.new('Phone LED reflected off concrete','POINT');d.color=(.64,.67,.70);d.shadow_soft_size=.3;d.use_shadow=False;o=bpy.data.objects.new(d.name,d);bpy.context.collection.objects.link(o);o.parent=p;o.location=(0,0,-.38)
for fr in range(1,434,2):
 t=(fr-1)/24;d.energy=1 if t<3.9 else 6;d.keyframe_insert(data_path='energy',frame=fr)
bpy.data.lights['Phone screen and scattered LED spill'].use_shadow=False
s.render.resolution_x=640;s.render.resolution_y=360;s.eevee.taa_render_samples=4;s.render.filepath='/workspace/intro-video-v3/frames/'
bpy.ops.wm.save_as_mainfile(filepath='/workspace/intro-video-v3/intro_v3.blend')
