import bpy,math
s=bpy.context.scene;led=bpy.data.lights['Smartphone LED only'];spill=bpy.data.lights['Phone screen and scattered LED spill']
for fr in range(1,434,2):
 t=(fr-1)/24;s.frame_set(fr)
 if t<3.9:
  led.energy=3.5*(.65+.35*math.sin(t*23));led.keyframe_insert(data_path='energy',frame=fr)
 spill.energy=1 if t<3.9 else 5;spill.keyframe_insert(data_path='energy',frame=fr)
 if t<1.6:
  cam=s.camera;cam.location.x+=.012*math.sin(t*39)*(1-t/1.6);cam.location.z+=.01*math.cos(t*34)*(1-t/1.6);cam.keyframe_insert(data_path='location',frame=fr)
s.eevee.taa_render_samples=4;s.render.resolution_x=768;s.render.resolution_y=432;s.render.filepath='/workspace/intro-video-v3/frames/';s.frame_set(169)
bpy.ops.wm.save_as_mainfile(filepath='/workspace/intro-video-v3/intro_v3.blend')
