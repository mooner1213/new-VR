import bpy, math, random, os
from mathutils import Vector
from math import sin,cos,pi
random.seed(17)
OUT='/workspace/intro-video-v3'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=8;s.eevee.use_gtao=True;s.eevee.gtao_distance=1.5;s.eevee.gtao_quality=.5;s.eevee.volumetric_samples=16;s.eevee.volumetric_tile_size='8'
s.render.resolution_x=768;s.render.resolution_y=432;s.render.resolution_percentage=100;s.render.fps=24;s.frame_start=1;s.frame_end=432
s.world.use_nodes=True;s.world.node_tree.nodes['Background'].inputs[0].default_value=(.002,.003,.004,1);s.world.node_tree.nodes['Background'].inputs[1].default_value=.06
s.view_settings.view_transform='AgX'
def mat(n,c,rough=.85,tex=False,emit=0):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough
 if emit:p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=emit
 if tex:
  ns=m.node_tree.nodes;links=m.node_tree.links;noise=ns.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=34;noise.inputs['Detail'].default_value=3
  ramp=ns.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=tuple(v*.35 for v in c)+(1,);ramp.color_ramp.elements[1].color=tuple(min(v*1.6,1) for v in c)+(1,);links.new(noise.outputs['Fac'],ramp.inputs[0]);links.new(ramp.outputs[0],p.inputs['Base Color'])
  bump=ns.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.5;bump.inputs['Distance'].default_value=.025;links.new(noise.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],p.inputs['Normal'])
 return m
concrete=mat('Coarse fractured concrete',(.24,.23,.21),tex=True);broken=mat('Light broken aggregate',(.39,.36,.31),tex=True);steel=mat('Rusty steel',(.16,.075,.035),.65,True);cloth=mat('Dusty clothing',(.12,.15,.16),tex=True);glove=mat('Dust coated gloves',(.21,.19,.15),tex=True);black=mat('Phone rubber',(.012,.015,.018),.45);glass=mat('Dark screen',(.012,.035,.045),.25,emit=.22);white=mat('Display text',(.50,.79,.84),emit=1);amber=mat('Warning header',(.9,.35,.08),emit=1);dustmat=mat('Concrete dust',(.27,.26,.24),.9)
def cube(n,loc,dim,m,rot=(0,0,0),bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=dim;o.rotation_euler=rot;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(m)
 if bevel:b=o.modifiers.new('Edge damage','BEVEL');b.width=bevel;b.segments=1;o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return o
def shard(n,loc,dim,m):
 o=cube(n,loc,dim,m)
 for v in o.data.vertices:
  for j in range(3):v.co[j]+=random.uniform(-.16,.16)*dim[j]
 o.rotation_euler=[random.uniform(-.4,.4) for _ in range(3)];o.modifiers.new('Weighted normals','WEIGHTED_NORMAL');return o
def sphere(n,loc,scale,m):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;o.data.materials.append(m)
 for p in o.data.polygons:p.use_smooth=True
 return o
def seg(n,a,b,r,m):
 bpy.ops.mesh.primitive_cylinder_add(vertices=10,radius=r,depth=1);o=bpy.context.object;o.name=n;o.data.materials.append(m);pose_seg(o,Vector(a),Vector(b));return o
def pose_seg(o,a,b):
 d=b-a;o.location=(a+b)/2;o.rotation_euler=d.to_track_quat('Z','Y').to_euler();o.scale.z=d.length
 return o
def empty(n):
 o=bpy.data.objects.new(n,None);bpy.context.collection.objects.link(o);return o
def key(o,fr,props=('location','rotation_euler','scale')):
 for p in props:o.keyframe_insert(data_path=p,frame=fr)
def parent_local(o,p,loc):o.parent=p;o.location=loc
# Enclosure: narrow wedge surrounding an immobile body. No open room.
cube('Subfloor',(0,.7,-.51),(3,4,.25),concrete)
for side in [-1,1]:
 for j in range(5):
  shard('Collapsed side wall',(side*random.uniform(.61,.78),-.9+j*.65,random.uniform(-.05,.15)),(random.uniform(.38,.65),.85,random.uniform(.65,.95)),concrete)
ceil=[]
for j in range(5):
 o=shard('Low collapsed ceiling',(random.uniform(-.09,.09),-.7+j*.65,.78+random.uniform(-.04,.05)),(1.6,.9,.30),concrete);ceil.append(o)
shard('End sealed by rubble',(0,2.0,0),(1.5,.8,1.35),concrete)
for i in range(70):
 x=random.uniform(-.65,.65);y=random.uniform(-.3,2);d=random.uniform(.04,.22);shard('Loose broken masonry',(x,y,-.30+random.uniform(-.03,.08)),(d,d*.85,d*.65),broken)
# Body clearly lies beneath slab, upper torso free.
sphere('Torso jacket',(0,-.70,-.25),(.27,.48,.16),cloth)
for x in [-.14,.14]:
 sphere('Pinned thigh',(x,.13,-.28),(.125,.46,.135),cloth)
 sphere('Pinned shin',(x,.85,-.31),(.10,.40,.105),cloth)
 sphere('Boot',(x,1.23,-.30),(.115,.18,.13),black)
 for y in [-.1,.04,.2]:seg('Trouser seam',(x-.09,y,-.165),(x+.09,y,-.165),.004,glove)
slab=shard('Slab crushing lower body',(0,.65,-.02),(1.13,.57,.35),concrete);slab.rotation_euler=(.07,-.10,.02)
for i in range(12):
 shard('Rubble on trapped legs',(random.uniform(-.44,.44),random.uniform(.5,1.1),random.uniform(.05,.15)),(.12,.13,.10),broken)
# Close detailed bent rebar: rods and actual rib rings.
for i in range(8):
 x=random.uniform(-.58,.58);y=random.uniform(-.25,1.7);z=random.uniform(.44,.65)
 points=[Vector((x-.24,y-.12,z)),Vector((x,y,z-.04)),Vector((x+.19,y+.25,z+.03))]
 for a,b in zip(points,points[1:]):
  seg('Bent rebar core',a,b,.012,steel);d=b-a
  for j in range(1,11):
   pos=a+d*j/11;bpy.ops.mesh.primitive_torus_add(major_radius=.013,minor_radius=.0025,major_segments=8,minor_segments=4,location=pos);o=bpy.context.object;o.name='Rebar raised rib';o.rotation_euler=d.to_track_quat('Z','Y').to_euler();o.data.materials.append(steel)
# Bent pipe at right edge and cloth within reach.
seg('Signal pipe',(.52,-.05,-.21),(.52,1.4,-.21),.03,steel)
shard('Cloth within reach',(.36,.12,-.30),(.20,.15,.018),glove)
# Smartphone and left hand move as one real 3D assembly.
phone=empty('LEFT hand smartphone rig')
p=cube('Smartphone body',(0,0,0),(.082,.165,.013),black,bevel=.007);parent_local(p,phone,(0,0,0))
p=cube('Screen',(0,0,0),(.071,.143,.003),glass,bevel=.003);parent_local(p,phone,(0,0,.008))
for txt,y,sz,m in [('EMERGENCY',.042,.009,amber),('EARTHQUAKE',.023,.007,white),('COVER MOUTH',-.005,.006,white),('STAY CALM',-.025,.006,white)]:
 bpy.ops.object.text_add();o=bpy.context.object;o.name='Phone message '+txt;o.data.body=txt;o.data.size=sz;o.data.align_x='CENTER';o.data.materials.append(m);parent_local(o,phone,(0,y,.010))
# Actual flashlight on rear of phone, pointing into scene; no room fill light.
d=bpy.data.lights.new('Smartphone LED only','SPOT');d.energy=0;d.color=(.78,.86,1);d.spot_size=math.radians(74);d.spot_blend=.42;d.shadow_soft_size=.018;o=bpy.data.objects.new('Phone LED',d);bpy.context.collection.objects.link(o);o.parent=phone;o.location=(.027,.063,-.013)
led=d
p=sphere('Left gloved palm',(0,0,0),(.043,.06,.024),glove);parent_local(p,phone,(-.025,-.047,-.025))
for i in range(4):
 x=-.04+i*.018
 p=seg('Left gripping finger',(x,-.002,-.02),(x,.038,-.018),.009,glove);p.parent=phone
 p=sphere('Left fingertip',(0,0,0),(.009,.016,.012),glove);parent_local(p,phone,(x,.040,-.01))
p=seg('Left thumb',(.035,-.05,.018),(.018,-.005,.025),.011,glove);p.parent=phone
right=empty('RIGHT protective hand rig');p=sphere('Right palm',(0,0,0),(.045,.057,.024),glove);p.parent=right
for i in range(4):
 x=-.032+i*.021
 for a,b in [((x,.035,0),(x,.077,-.008)),((x,.077,-.008),(x,.105,-.025))]:
  p=seg('Right glove finger',a,b,.009,glove);p.parent=right
p=seg('Right thumb',(-.04,-.012,0),(-.07,.025,-.005),.012,glove);p.parent=right
arms={}
for side in ['L','R']:
 arms[side]=[seg(side+' sleeve upper',(0,0,0),(0,0,1),.065,cloth),seg(side+' sleeve forearm',(0,0,0),(0,0,1),.048,cloth)]
# Camera: limited upper-body/head motion, never walking through the scene.
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='Seated trapped survivor POV';cam.data.lens=19;cam.data.clip_start=.035;cam.data.clip_end=20;s.camera=cam
# Small real particles drift through beam, animated objects rather than composited image specks.
particles=[]
for i in range(130):
 bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=random.uniform(.001,.004),location=(random.uniform(-.55,.55),random.uniform(-.5,1.7),random.uniform(-.25,.65)));o=bpy.context.object;o.name='Airborne concrete dust';o.data.materials.append(dustmat);particles.append((o,o.location.copy(),random.uniform(.02,.065)))
# Actual falling fragments at two moments.
for event in [0.3,9.0]:
 for i in range(15):
  x=random.choice([-1,1])*random.uniform(.28,.55);y=random.uniform(-.05,1.25);d0=random.uniform(.012,.05);o=shard('Falling aftershock fragment',(x,y,.6),(d0,d0,d0),broken)
  start=event+random.uniform(0,.65)
  for tt,z in [(0,.72),(start,.65),(start+.40,-.27),(start+.55,-.20),(start+.75,-.29),(18,-.29)]:
   o.location=(x+.035*sin(tt*8),y+.025*cos(tt*8),z);o.rotation_euler=(tt*2,tt,tt*.7);key(o,max(1,int(tt*24)),('location','rotation_euler'))
# Volumetric concrete dust: phone beam alone reveals its density.
m=bpy.data.materials.new('Suspended powder volume');m.use_nodes=True;ns=m.node_tree.nodes;ns.clear();out=ns.new('ShaderNodeOutputMaterial');vol=ns.new('ShaderNodeVolumePrincipled');vol.inputs['Density'].default_value=.10;vol.inputs['Color'].default_value=(.48,.46,.42,1);vol.inputs['Anisotropy'].default_value=.25;m.node_tree.links.new(vol.outputs['Volume'],out.inputs['Volume']);cube('Dust volume',(0,.5,.15),(1.5,3,1.35),m)
# Animation keys. Body is static; head, arms, lights, overhead slab and fragments are independent.
def smooth(a,b,t):
 u=max(0,min(1,t));u=u*u*(3-2*u);return Vector(a).lerp(Vector(b),u)
for fr in range(1,434,2):
 t=(fr-1)/24;shock=math.exp(-((t-9.5)/.65)**2);breath=.008*sin(t*2.6)
 cam.location=(.014*sin(t*.75)+shock*.009*sin(t*36),-1.02+breath,.39+.009*sin(t*2.6))
 target=Vector((.02*sin(t*.6),.65,-.17))
 # Intentional look down to visibly pinned legs, then up to dangerous ceiling.
 if 6<t<8:target.z-=.16*sin((t-6)/2*pi)
 if 9<t<12:target.z+=.48*sin((t-9)/3*pi)
 cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();key(cam,fr,('location','rotation_euler'))
 pl=smooth((-.26,-.12,-.20),(-.26,-.20,.19),(t-3.7)/1.6)
 pl+=Vector((.025*sin(t*.75),breath,.012*sin(t*1.6)))
 phone.location=pl
 aim=Vector((.1+.25*sin(t*.55),.9,.12+.20*sin(t*.7)))
 phone.rotation_euler=(pl-aim).to_track_quat('Z','Y').to_euler();key(phone,fr,('location','rotation_euler'))
 led.energy=0 if t<3.9 else (12*(.94+.06*sin(t*4))*(1-.5*shock*(.5+.5*sin(t*32))))
 led.keyframe_insert(data_path='energy',frame=fr)
 pr=Vector((.30,-.18,-.12))
 if 8.8<t<12.4:
  pr=smooth(pr,(.12,-.45,.48),(t-8.8)/.6) if t<10 else smooth((.12,-.45,.48),(.30,-.18,-.12),(t-11.2)/1.2)
 pr.z+=breath;right.location=pr;right.rotation_euler=(.4 if t<9 or t>12 else -.5,0,-.35);key(right,fr,('location','rotation_euler'))
 for side,wrist,shoulder,elbow in [('L',pl,(-.22,-.87,-.16),(-.40,-.55,-.06)),('R',pr,(.22,-.87,-.16),(.40,-.48,-.05))]:
  el=Vector(elbow);el.z+=max(0,wrist.z)*.5
  for obj,a,b in [(arms[side][0],Vector(shoulder),el),(arms[side][1],el,wrist)]:pose_seg(obj,a,b);key(obj,fr)
 for o,base,speed in particles:
  o.location=(base.x+.025*sin(t*.6+base.y*5),base.y+.02*sin(t*.9),-.28+(base.z+.28-t*speed)% .91);key(o,fr,('location',))
for o in ceil:
 z=o.location.z
 for t,dz in [(0,.035),(1.2,0),(8.9,0),(9.8,-.035),(18,-.035)]:o.location.z=z+dz;key(o,int(t*24)+1,('location',))
# Use linear interpolation for sampled motion and falling debris.
for ob in bpy.data.objects:
 if ob.animation_data and ob.animation_data.action:
  for fc in ob.animation_data.action.fcurves:
   for k in fc.keyframe_points:k.interpolation='LINEAR'
s.render.image_settings.file_format='PNG';s.render.filepath=OUT+'/frames/'
s.frame_set(169)
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/intro_v3.blend')
s.render.filepath=OUT+'/test.png';bpy.ops.render.render(write_still=True)
